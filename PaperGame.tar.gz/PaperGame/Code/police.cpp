#include "police.hh"

//Constructeur
Police::Police()
{
 Element();
 this->image = new QPixmap("police.jpg");
image->scaled(30,60);
}

//Obtenir l'image
QPixmap* Police::GetImage(){
    return this->image ;
}

