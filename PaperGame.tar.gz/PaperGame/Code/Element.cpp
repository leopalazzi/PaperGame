#include "Element.hh"
#include <vector>

//Constructeurs
Element::Element()
{
    //ctor
    this->nom = "Vide";
    this->x = 0 ;
    this->y = 0 ;
}

// Surcharge
Element::Element(std::string nom)
{
    this->nom = nom;
}


//Mettre a jour le nom
void Element::SetNom(std::string nom)
{
		this->nom = nom ;
}

//Obtenir le nom
std::string  Element::GetNom()
{
	return this->nom;
}


Element::~Element()
{
    //dtor
}

//Mettre à jour la position
void Element::SetPos(int x, int y){
    this->x = x ;
    this->y = y ;

}

//Obtenir la position en x
int Element::Getx(){
    return this->x;
}
//Obtenir la position en y
int Element::Gety(){
    return this->y;
}
