#ifndef EVENEMENTS_HH
#define EVENEMENTS_HH

#endif // EVENEMENTS_HH

class Evenements
{
protected :
    float benef;
    float perte;
public:
    Evenements();
    void event();
    float GetBenef();
    float GetPerte();
    void SetDetails(float benef , float perte);
};
