#ifndef POLICE_HH
#define POLICE_HH
#include <QtGui>
#include <QVBoxLayout>
#include "Element.hh"
#include "Compte.hh"
#include <list>
using namespace std;

class Police : public Element
{
public:
    Police();
      QPixmap* GetImage();
private:

     QPixmap *image;
};

#endif // POLICE_HH
