#ifndef ELEMENT_HH
#define ELEMENT_HH

#include <string>

using namespace std;
class Element{

	public :
		Element();
		Element(std::string nom);
		~Element();
		std::string GetNom();
		void SetNom(std::string nom);
     void SetPos(int x, int y);
        int Getx();
        int Gety();
protected:
		std::string nom ;
        int x ;
        int y ;



};

#endif // ELEMENT_HH
