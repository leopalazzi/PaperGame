#include "Personage.hh"

//Constructeur
Personnage::Personnage()
{
    Element();
   solde = 1000000;
    this->image = new QPixmap("perso.png");
   image->scaled(30,60);
    //ctor
}

//Obtenir l'image
QPixmap* Personnage::GetImage(){
    return this->image ;
}


Personnage::~Personnage()
{
    //dtor
}


