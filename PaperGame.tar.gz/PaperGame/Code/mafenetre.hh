#include <QApplication>
#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <list>
#include <QVBoxLayout>
#include <QApplication>
#include <QtGui>
#include <QTextEdit>
#include <QtWidgets>
#include <iostream>
#include <string>
#include "Pays.hh"
#include "Personage.hh"
#include "dice.hh"
#include "police.hh"





class MaFenetre : public QWidget // On hérite de QWidget (IMPORTANT)
{
    Q_OBJECT
    public:
    MaFenetre(int x, int y, const char* chaine);
     MaFenetre(int x, int y);
     void InitPays();
     void PlacerBoutonsEtPays(QPushButton *lebouton,float x,float y,int longeur,int largeur,QString nompays,Pays *adefinir,int solde);
     void InfosPays(QWidget *fenetre ,QLabel *label, QPushButton *cashout,QGridLayout *layout, QFormLayout *layout2, QGridLayout *layout3,QString str1);
    QLabel *image2;
    QLabel *image3;
     public slots:
        void Setsolde(int i); // regle le solde lorsquon appuie sur le bouton
        void afficher();
        void sleep(int time);
        void afficherPosition();
        void deplacement_perso(int dest_x , int dest_y);
         void deplacement_police(int dest_x , int dest_y);
        void afficherUsa();
        void patrouille();
        void afficherCanada();
        void afficherBresil();
        void afficherArgentine();
        void afficherFrance();
        void afficherAfrique();
        void afficherQatar();
        void afficherInde();
        void afficherChine();
        void persoInit();
        void policeInit();
        void actualiserPays();
        void Investir();
        void CashOut();
        void lancer();
    private:
        dice de;
    std::vector<QString> listeChaine;
    std::list<Pays> listePays;
    int pos_cour;
    std::string pays_cour; // nom du pays courant
    QLabel *image;
    QTextEdit *texte;
    QPushButton *bouton;
    QPushButton *bouton1;
    QPushButton *bouton2;
    QPushButton *bouton3;
    QPushButton *bouton4;
    QPushButton *bouton5;
    QPushButton *bouton6;
    QPushButton *bouton7;
    QPushButton *bouton8;
    QPushButton *bouton9;
    QPushButton *diceb ;
    Personnage perso;
    Police police;
    QTextEdit *texte_cour;
    QTime dieTime;
    int largeurEcran;
    int hauteurEcran;
};
