#include "mafenetre.hh"
#include "Pays.hh"
#include <sstream>


using namespace std;

int newsolde; // Le nouveau solde
Pays payscour; //Le pays sur lequel on se trouve

/*
____________________________________________________________________________________________
    Les Opérateurs
____________________________________________________________________________________________
*/

//Afficher le solde
std::ostream& operator<<(ostream& os, const Compte& c)
{
  os<<c.solde;
  return os;
}

//Les operations pour afficher des chaines
QString operator+(string chaine, QString chaine2)
{
    QString nouveaux;
    nouveaux =  QString::fromStdString(chaine) + chaine2;

  return nouveaux;
}

QString operator+(QString chaine,string chaine2)
{
  chaine += QString::fromStdString(chaine2);
  return chaine;
}

QString operator+(QString chaine,int solde)
{
  chaine += QString::number(solde);
  return chaine;
}

string operator+(string chaine,float chaine2)
{
    ostringstream os;
      os << chaine2;
     string nouvelle = chaine+   os.str();

  return nouvelle;
}


/*
____________________________________________________________________________________________
    Constructeurs
____________________________________________________________________________________________
*/

MaFenetre::MaFenetre(int x,int y,const char* chaine) : QWidget()
{

    setFixedSize(x,y);
    largeurEcran = QApplication::desktop()->screenGeometry().width(); // largeur de notre cran
    hauteurEcran = QApplication::desktop()->screenGeometry().height(); // hauteur de notre ecran

    image = new QLabel(this); // on charge une image dans la fenetre
    QPixmap pixmap(chaine); // image de nom "chaine"
    pixmap = pixmap.scaled(QSize(x,y),Qt::IgnoreAspectRatio); // on le met à la bonne echelle

    image->setPixmap(pixmap); // on met l'image
    image->resize(this->size());
    image2 = new QLabel(this);

    image3 = new QLabel(this);

    InitPays();
    persoInit();
    policeInit();

    texte_cour =  new QTextEdit(this); // zone de texte
    texte_cour->viewport()->setAutoFillBackground(false); // sans background
    texte_cour->setGeometry(largeurEcran*0.2,hauteurEcran*0.6,largeurEcran*0.24,60); //on choisit la taille et la position
    texte_cour->setText("Cliquez sur le dé pour commencer le jeu.");
    listeChaine.push_back("Bravo vous avez investit !");
    listeChaine.push_back("Bravo vous avez Cash out !");
    listeChaine.push_back("Vous avez tout investit. Vous avez perdu.\nBye !");


    diceb = new QPushButton(this); // le dé
    diceb->setGeometry(largeurEcran*(1 - 0.56),hauteurEcran*(1-0.4),60,60);
    diceb->setText("Dé");

    //On connecte tout nos boutons aux slots voulus
    QObject::connect(bouton, SIGNAL(clicked()), this, SLOT(afficherUsa()));
    QObject::connect(bouton2, SIGNAL(clicked()), this, SLOT(afficherCanada()));
    QObject::connect(bouton3, SIGNAL(clicked()), this, SLOT(afficherArgentine()));
    QObject::connect(bouton4, SIGNAL(clicked()), this, SLOT(afficherBresil()));
    QObject::connect(bouton5, SIGNAL(clicked()), this, SLOT(afficherFrance()));
    QObject::connect(bouton6, SIGNAL(clicked()), this, SLOT(afficherAfrique()));
    QObject::connect(bouton7, SIGNAL(clicked()), this, SLOT(afficherQatar()));
    QObject::connect(bouton8, SIGNAL(clicked()), this, SLOT(afficherInde()));
    QObject::connect(bouton9, SIGNAL(clicked()), this, SLOT(afficherChine()));
    QObject::connect(diceb, SIGNAL(clicked()), this, SLOT(lancer()));

}

//Surcharge
MaFenetre::MaFenetre(int x,int y)
{
 setFixedSize(x,y);
}

/*
____________________________________________________________________________________________
    Fonctions
____________________________________________________________________________________________
*/

//Faire une pause de time ms
void MaFenetre::sleep(int time)
{
    dieTime = QTime::currentTime().addMSecs(time);
    while (QTime::currentTime() < dieTime)
        QCoreApplication::processEvents(); // (QEventLoop::AllEvents, 100)
}

//Placement des boutons et des pays
void MaFenetre::PlacerBoutonsEtPays(QPushButton *lebouton,float x,float y,int longeur,int largeur,QString nompays,Pays *adefinir,int solde)
{
    lebouton->setGeometry((float)largeurEcran*(1-x),(float)hauteurEcran*(1-y),longeur,largeur);
    lebouton->setText(nompays);
    adefinir->SetPos(largeurEcran*(1 - x),hauteurEcran*(1-y));
    adefinir->SetSolde(solde);
     listePays.push_back(*adefinir);
}

//Initialisation des Pays
void MaFenetre::InitPays(){
    //genere les stat des pays aleatoirement
    bouton = new QPushButton(this);
    Pays *usa = new Pays("USA",1);
    PlacerBoutonsEtPays(bouton,0.87,0.8,60,40,"USA",usa,0);
    bouton->setStyleSheet("color: red;");
    pays_cour = usa->GetNom();


    bouton2 = new QPushButton(this);
    Pays *canada = new Pays("Canada",2);
    PlacerBoutonsEtPays(bouton2,0.84,0.86,60,40,"Canada",canada,0);
    bouton2->setStyleSheet("color: red;");

    bouton3 = new QPushButton(this);
    Pays *argentine = new Pays("Argentine",8) ;
    PlacerBoutonsEtPays(bouton3,0.84,0.5,47,40,"Argentine",argentine,0);
    bouton3->setStyleSheet("font-size : 10px;color:#48D1CC;");

    bouton4 = new QPushButton(this);
    Pays *bresil = new Pays("Bresil",9) ;
    PlacerBoutonsEtPays(bouton4,0.82,0.6,60,40,"Bresil",bresil,0);
     bouton4->setStyleSheet("font-size : 10px;color : green;");

   bouton5 = new QPushButton(this);
   Pays *france = new Pays("France",3) ;
   PlacerBoutonsEtPays(bouton5,0.67,0.83,50,30,"France",france,0);
    bouton5->setStyleSheet("color : blue;");

    bouton6 = new QPushButton(this);
    Pays *afrique = new Pays("Afrique du Sud",7) ;
    PlacerBoutonsEtPays(bouton6,0.64,0.55,65,30,"Afrique du Sud",afrique,0);
    bouton6->setStyleSheet("font-size : 9px;color: green;");


    bouton7 = new QPushButton(this);
    Pays *qatar = new Pays("Qatar",4) ;
    PlacerBoutonsEtPays(bouton7,0.57,0.69,40,40,"Qatar",qatar,0);
    bouton7->setStyleSheet("color:  #B22222;");

    bouton8 = new QPushButton(this);
    Pays *inde = new Pays("Inde",5) ;
    PlacerBoutonsEtPays(bouton8,0.5,0.68,40,40,"Inde",inde,0);
    bouton8->setStyleSheet("color : #FF8C00;");

    bouton9 = new QPushButton(this);
    Pays *chine = new Pays("Chine",6) ;
    PlacerBoutonsEtPays(bouton9,0.47,0.78,80,60,"Chine",chine,0);
    bouton9->setStyleSheet("color :#FF0000");
    srand(time(NULL)); // initialisation de rand

    for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++)
    {
        it->SetDetails(rand() %  101 , rand() %101);

    }

}

//Initialisation du perso
void MaFenetre::persoInit(){

    for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++){
        if(it->GetNom() == pays_cour){
        perso.SetPos(it->Getx()+30,it->Gety()+30);
        pos_cour = 1 ;
        }
    }

    image2->setPixmap(*perso.GetImage());
       image2->resize(perso.GetImage()->size());
       image2->move(perso.Getx(),perso.Gety());

}
// initialisation police
void MaFenetre::policeInit(){
    image3->setPixmap(*police.GetImage());
       image3->resize(police.GetImage()->size());
       image3->move(police.Getx(),police.Gety());
}

/*
____________________________________________________________________________________________
    Fonctions slots
____________________________________________________________________________________________
*/

//Mis à jour de la variable newsolde
void MaFenetre::Setsolde(int i)
{
    newsolde = i;
}

//Investissement
void MaFenetre::Investir(){
    QWidget *fenetre = new QWidget(); //une nouvelle fenetre va s'afficher
    QLabel *label = new QLabel(fenetre);
    QString chaine;
    fenetre->setStyleSheet("background-color : #000080");
    label->setStyleSheet("color : #bfa100;font-weight:bold;");
    if(perso.solde - newsolde*1000 >=0)
    {
        for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++){
            if(it->GetNom() == pays_cour){
               it->AddSolde(newsolde*1000);
              chaine =  QString::fromStdString("\nSolde du pays : $")+ it->GetSolde() +  QString::fromStdString("\nVotre Solde : $") + perso.GetSolde();

            }
        }
    perso.SetSolde(-newsolde*1000);
   fenetre->setFixedSize(largeurEcran*0.2,hauteurEcran*0.1);
   //on met toutes les informations necessaires
    label->setText(this->listeChaine[0]+ chaine);
       fenetre->show();
       this->sleep(1500);
      fenetre->close();
    }
    else
    {
QMessageBox::critical(this, "Annulation opération", "Votre banque n'autorise pas cette autorisation!\nVotre solde : $"+QString::number(perso.GetSolde()));
    }
}
//Fonction pour cash out le montant voulu
void MaFenetre::CashOut(){

    QWidget *fenetre = new QWidget();
    QLabel *label = new QLabel(fenetre);
     QString chaine;
    fenetre->setStyleSheet("background-color : #000080");
    label->setStyleSheet("color : #bfa100;");

    if(payscour.GetSolde() - newsolde*1000 >= 0 ){

        for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++){
            if(it->GetNom() == pays_cour){
               it->AddSolde(-newsolde*1000);
              chaine =  QString::fromStdString("\nSolde du pays : $")+ it->GetSolde() +  QString::fromStdString("\nVotre Solde : $") + perso.GetSolde();

            }
        }
        perso.SetSolde(newsolde*1000);
        fenetre->setFixedSize(largeurEcran*0.2,hauteurEcran*0.1);
       chaine = QString::fromStdString("\nSolde du pays : $") + payscour.GetSolde() +  QString::fromStdString("\nVotre Solde : $") + perso.GetSolde();
        label->setText(this->listeChaine[1] + chaine);
        fenetre->show();
         this->sleep(1500);
        fenetre->close();
       }
    else
    {
QMessageBox::critical(this, "Annulation opération", "Votre banque n'autorise pas cette autorisation!\nVotre solde : $"+QString::number(perso.GetSolde()));
    }


}
//Lancement du dé
void MaFenetre::lancer(){
    QPixmap pixmap;
     texte_cour->setText("Nouveau Tour.");
     QString str1 ;
     str1 = QString::fromStdString("Votre solde :") + perso.GetSolde();
       texte_cour->append(str1);
    int indice ;
    int res ;
    for(int i = 0 ; i< 5 ; i++){
        res = de.call();
        cout << " resultat dé : " << res  << endl ;
        switch(res){ // on affiche l'image correspondante
        case 1:
             pixmap.load("un.jpg");
            diceb->setIcon(pixmap);
            break;
        case 2:
             pixmap.load("deux.jpg");
             diceb->setIcon(pixmap);
            break;
        case 3:
            pixmap.load("trois.jpg");
            diceb->setIcon(pixmap);
            break;
        case 4:
            pixmap.load("quatre.jpg");
            diceb->setIcon(pixmap);
            break;
        case 5:
            pixmap.load("cinq.jpg");
            diceb->setIcon(pixmap);
            break;
        case 6:
            pixmap.load("sis.jpg");
            diceb->setIcon(pixmap);
            break;
        default:
            break;
     }
    }
    if((pos_cour + res) <= 9)
        indice = pos_cour + res ;
    else
        indice = pos_cour+ res - 9 ;
    if(indice < 1)
        indice = 1;

    // on doit deplacer le personnage sur le pays en question
    for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++){
        if(it->num ==  indice){
         pays_cour = it->GetNom();
         pos_cour = it->num ;
         str1 = "Vous etes arrivé a " +  QString::fromStdString(pays_cour) +"\n";
         texte_cour->append(str1);

        }
     }
       for(int j = pos_cour; j <= indice ; j++ ){
        for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++){
            if(it->num == j){
             pays_cour = it->GetNom();
             deplacement_perso(it->Getx()+10,it->Gety()+10);
             this->sleep(10);

            }
       }
    }
    pos_cour = indice ;
    cout << " Position : " << pos_cour << endl;

    patrouille();
    actualiserPays();
    //fin du jeu
    if(perso.GetSolde() <= 0){
        QMessageBox::critical(this, "Aurevoir", listeChaine[2]);
        this->close();

    }
}

void MaFenetre::patrouille(){
    srand (time(NULL));
    int n;
    n= rand(); // position au hazard de la police
    n = 1 + n % 9;
    cout << "police en " << n << endl ;


    for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++){
        if(it->num == n){
       cout << "passe son tour " << endl ;
         deplacement_police(it->Getx()+40,it->Gety()+40); // recherche pays position police
        }
      }

    if(n == pos_cour ){ // si perso et police sur le meme pays
         texte_cour->setText("La police vous a attrapé ! Vous payer une amende de $ 200,000");
         perso.SetSolde(-200000);
    }
}

//Actualisation du Pays
void MaFenetre::actualiserPays(){
    srand (time(NULL));
   QString str1 ;
    int randb = 0 ;
    int randp = 0 ;
    for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++)
    {
        randb = rand();
        randb = randb % 100;
        randp = rand();
        randp = randp % 100;
        str1 = QString::fromStdString(it->GetNom()) + QString::fromStdString(" Perte :") + QString::number(it->GetPerte()) + QString::fromStdString(" Benefice :") + QString::number(it->GetBenef());

       it->SetDetails( (it->GetBenef() * randb/100),(it->GetPerte() * randp/100));
       it->AddSolde(it->GetBenef() + it->GetPerte());
    }
       texte_cour->append(str1);


}

// Deplacement du personnage
void MaFenetre::deplacement_perso(int dest_x , int dest_y){
    int i, j ;
    bool flag1 = false ;
    bool flag2 = false;
    i = perso.Getx();
    j = perso.Gety();
    //On va d'abord à la position en x
    while(!(flag1)){
       if(i>dest_x)
           i--;
       else if(i<dest_x)
           i++;
       perso.SetPos(i,j);
       image2->move(perso.Getx(),perso.Gety());
       this->sleep(5);
       if(perso.Getx() == dest_x)
           flag1 = true ;

    }
    //Puis à la position en y
    while(!(flag2)){
        if(j>dest_y)
            j--;
        else if(j<dest_y)
            j++;

        perso.SetPos(i,j);
        image2->move(perso.Getx(),perso.Gety());
        this->sleep(5);
        if (perso.Gety() == dest_y)
            flag2 = true ;
    }
}

//Le deplacement de la police
void MaFenetre::deplacement_police(int dest_x , int dest_y){
    int i, j ;
    bool flag1 = false ;
    bool flag2 = false;
    i = police.Getx();
    j = police.Gety();
    while(!(flag1)){

       if(i>dest_x)
           i--;
       else if(i<dest_x)
           i++;
       police.SetPos(i,j);
       image3->move(police.Getx(),police.Gety());
       this->sleep(5);


       if(police.Getx() == dest_x)
           flag1 = true ;

    }

    while(!(flag2)){

        if(j>dest_y)
            j--;
        else if(j<dest_y)
            j++;

        police.SetPos(i,j);
        image3->move(police.Getx(),police.Gety());
        this->sleep(5);

        if (police.Gety() == dest_y)
            flag2 = true ;
    }

}

void MaFenetre::afficher()
{
    this->show();
}



void MaFenetre::InfosPays( QWidget *fenetre ,QLabel *label, QPushButton *cashout,QGridLayout *layout, QFormLayout *layout2, QGridLayout *layout3,QString str1){
    QPushButton *investi = new QPushButton(fenetre);
    QVBoxLayout *layoutPrincipal = new QVBoxLayout;
    QSpinBox *investissement = new QSpinBox;
    QString soldePays,soldePerso;

    QObject::connect(investi, SIGNAL(clicked()), this, SLOT(Investir()));
    QObject::connect(cashout, SIGNAL(clicked()), this, SLOT(CashOut()));

    QObject::connect(investissement, SIGNAL(valueChanged(int)),this, SLOT(Setsolde(int)));
    investissement->setMaximum(1000);
    fenetre->setFixedSize(this->largeurEcran*(1-0.7),this->hauteurEcran*(1-0.7));
    label->setStyleSheet("font-style:Blippo; font-size:18px;");
    label->setText(str1);
    layout->addWidget(label,0,0);
layout->setHorizontalSpacing(3);
layoutPrincipal->addLayout(layout);
layout2->addRow("Investissement dans ce pays (en k$):", investissement);
layoutPrincipal->addLayout(layout2);
fenetre->setLayout(layoutPrincipal);
cashout->setStyleSheet("font-style : Blippo;color : yellow;background : grey;");
cashout->setText("Cash Out");
investi->setStyleSheet("font-style : Blippo;color : yellow;background : grey;");
  investi->setText("Investir la somme");
  layout3->addWidget(investi,0,0);
layout3->addWidget(cashout,0,1);
   layoutPrincipal->addLayout(layout3);
fenetre->show();

}

void MaFenetre::afficherUsa(){
  QWidget *fenetre = new QWidget();
    QLabel *label = new QLabel(fenetre);
    QPushButton *cashout = new QPushButton(fenetre);
    QGridLayout *layout = new QGridLayout;
     QFormLayout *layout2 = new QFormLayout;
     QGridLayout *layout3 = new QGridLayout;
    QString str1;
    QString str2 ;
    QString str3 ;

    for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++)
      {
        if(it->GetNom() == "USA"){
        payscour = *it;
         str1 = it->GetNom() + "\nPerte :" + it->GetPerte()+ "\nBenefice :" + it->GetBenef()
                 + "\n Solde :" + QString::number(it->GetSolde());
        }
    }
    if (pays_cour == "USA")
        InfosPays(fenetre,label,cashout,layout,layout2,layout3,str1);
    else
        texte_cour->setText("Vous ne pouvez pas investir/CashOut dans ce pays");



}
void MaFenetre::afficherCanada(){
    QWidget *fenetre = new QWidget();
      QLabel *label = new QLabel(fenetre);
      QPushButton *cashout = new QPushButton(fenetre);
      QGridLayout *layout = new QGridLayout;
       QFormLayout *layout2 = new QFormLayout;
       QGridLayout *layout3 = new QGridLayout;
      QString str1;
      QString str2 ;
      QString str3 ;

      for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++)
        {
          if(it->GetNom() == "Canada"){
          payscour = *it;
           str1 = it->GetNom() + "\nPerte :" + it->GetPerte()+ "\nBenefice :" + it->GetBenef()
                   + "\n Solde :" + QString::number(it->GetSolde());
          }
      }
      if(pays_cour ==  "Canada")
        InfosPays(fenetre,label,cashout,layout,layout2,layout3,str1);
      else
          texte_cour->setText("Vous ne pouvez pas investir/CashOut dans ce pays");
}

void MaFenetre::afficherBresil(){

    QWidget *fenetre = new QWidget();
      QLabel *label = new QLabel(fenetre);
      QPushButton *cashout = new QPushButton(fenetre);
      QGridLayout *layout = new QGridLayout;
       QFormLayout *layout2 = new QFormLayout;
       QGridLayout *layout3 = new QGridLayout;
      QString str1;
      QString str2 ;
      QString str3 ;

      for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++)
        {
          if(it->GetNom() == "Bresil"){
          payscour = *it;
           str1 =  it->GetNom() + "\nPerte :" + it->GetPerte()+ "\nBenefice :" + it->GetBenef()
                   + "\n Solde :" + QString::number(it->GetSolde());
          }
      }
      if(pays_cour ==  "Bresil")
         InfosPays(fenetre,label,cashout,layout,layout2,layout3,str1);
      else
          texte_cour->setText("Vous ne pouvez pas investir/CashOut dans ce pays");

}





void MaFenetre::afficherArgentine(){
    QWidget *fenetre = new QWidget();
      QLabel *label = new QLabel(fenetre);
      QPushButton *cashout = new QPushButton(fenetre);
      QGridLayout *layout = new QGridLayout;
       QFormLayout *layout2 = new QFormLayout;
       QGridLayout *layout3 = new QGridLayout;
      QString str1;
      QString str2 ;
      QString str3 ;

      for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++)
        {
          if(it->GetNom() == "Argentine"){
          payscour = *it;
            str1 = it->GetNom() + "\nPerte :" + it->GetPerte()+ "\nBenefice :" + it->GetBenef()
                   + "\n Solde :" + QString::number(it->GetSolde());
          }
      }

       if(pays_cour ==  "Argentine")
            InfosPays(fenetre,label,cashout,layout,layout2,layout3,str1);
       else
           texte_cour->setText("Vous ne pouvez pas investir/CashOut dans ce pays");
}

void MaFenetre::afficherFrance(){


    QWidget *fenetre = new QWidget();
      QLabel *label = new QLabel(fenetre);
      QPushButton *cashout = new QPushButton(fenetre);
      QGridLayout *layout = new QGridLayout;
       QFormLayout *layout2 = new QFormLayout;
       QGridLayout *layout3 = new QGridLayout;
      QString str1;
      QString str2 ;
      QString str3 ;

      for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++)
        {
          if(it->GetNom() == "France"){
          payscour = *it;
           str1  = it->GetNom() + "\nPerte :" + it->GetPerte()+ "\nBenefice :" + it->GetBenef()
                   + "\n Solde :" + QString::number(it->GetSolde());
          }
      }
       if(pays_cour ==  "France")
        InfosPays(fenetre,label,cashout,layout,layout2,layout3,str1);
       else
           texte_cour->setText("Vous ne pouvez pas investir/CashOut dans ce pays");
}

void MaFenetre::afficherAfrique(){
    QWidget *fenetre = new QWidget();
      QLabel *label = new QLabel(fenetre);
      QPushButton *cashout = new QPushButton(fenetre);
      QGridLayout *layout = new QGridLayout;
       QFormLayout *layout2 = new QFormLayout;
       QGridLayout *layout3 = new QGridLayout;
      QString str1;
      QString str2 ;
      QString str3 ;

      for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++)
        {
          if(it->GetNom() == "Afrique du Sud"){
          payscour = *it;
           str1 =  it->GetNom() + "\nPerte :" + it->GetPerte()+ "\nBenefice :" + it->GetBenef()
                   + "\n Solde :" + QString::number(it->GetSolde());
          }
      }
       if(pays_cour ==  "Afrique du Sud")
            InfosPays(fenetre,label,cashout,layout,layout2,layout3,str1);
       else
           texte_cour->setText("Vous ne pouvez pas investir/CashOut dans ce pays");


}


void MaFenetre::afficherQatar(){
    QWidget *fenetre = new QWidget();
      QLabel *label = new QLabel(fenetre);
      QPushButton *cashout = new QPushButton(fenetre);
      QGridLayout *layout = new QGridLayout;
       QFormLayout *layout2 = new QFormLayout;
       QGridLayout *layout3 = new QGridLayout;
      QString str1;
      QString str2 ;
      QString str3 ;

      for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++)
        {
          if(it->GetNom() == "Qatar"){
          payscour = *it;
           str1 =   str1 = it->GetNom() + "\nPerte :" + it->GetPerte()+ "\nBenefice :" + it->GetBenef()
                   + "\n Solde :" + QString::number(it->GetSolde());
          }
      }

      if(pays_cour == "Qatar")
        InfosPays(fenetre,label,cashout,layout,layout2,layout3,str1);
      else
          texte_cour->setText("Vous ne pouvez pas investir/CashOut dans ce pays");

}

void MaFenetre::afficherInde(){

    QWidget *fenetre = new QWidget();
      QLabel *label = new QLabel(fenetre);
      QPushButton *cashout = new QPushButton(fenetre);
      QGridLayout *layout = new QGridLayout;
       QFormLayout *layout2 = new QFormLayout;
       QGridLayout *layout3 = new QGridLayout;
      QString str1;
      QString str2 ;
      QString str3 ;

      for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++)
        {
          if(it->GetNom() == "Inde"){
          payscour = *it;
           str1 = it->GetNom() + "\nPerte :" + it->GetPerte()+ "\nBenefice :" + it->GetBenef()
                   + "\n Solde :" + QString::number(it->GetSolde());
          }
      }
      if(pays_cour  == "Inde")
        InfosPays(fenetre,label,cashout,layout,layout2,layout3,str1);
      else
          texte_cour->setText("Vous ne pouvez pas investir/CashOut dans ce pays");

}

void MaFenetre::afficherChine(){
    QWidget *fenetre = new QWidget();
      QLabel *label = new QLabel(fenetre);
      QPushButton *cashout = new QPushButton(fenetre);
      QGridLayout *layout = new QGridLayout;
       QFormLayout *layout2 = new QFormLayout;
       QGridLayout *layout3 = new QGridLayout;
      QString str1;
      QString str2 ;
      QString str3 ;

      for (list<Pays>::iterator it = listePays.begin(); it != listePays.end(); it++)
        {
          if(it->GetNom() == "Chine"){
          payscour = *it;
          str1 = it->GetNom() + "\nPerte :" + it->GetPerte()+ "\nBenefice :" + it->GetBenef()
                  + "\n Solde :" + QString::number(it->GetSolde());
          }
      }

      if(pays_cour == "Chine")
      InfosPays(fenetre,label,cashout,layout,layout2,layout3,str1);
      else
          texte_cour->setText("Vous ne pouvez pas investir/CashOut dans ce pays");


}





void MaFenetre::afficherPosition()
{
  int i =  QString::number(cursor().pos().x()).toInt();
  int j =  QString::number(cursor().pos().y()).toInt();

   cout<<i<<endl;
  this->image2->move(i,j);
}

