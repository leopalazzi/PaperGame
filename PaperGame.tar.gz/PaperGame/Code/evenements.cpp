#include "evenements.hh"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//Constructeurs
Evenements::Evenements()
{
    benef = 0;
     perte = 0;

}

//Obtenir le benefice
float Evenements::GetBenef(){
    return this->benef;
}

//Obtenir la perte
float Evenements::GetPerte(){
    return this->perte;
}

//Mettre à jours les valeurs

void Evenements::SetDetails(float benef , float perte){
    this->perte = -perte ;
    this->benef = benef ;
}


