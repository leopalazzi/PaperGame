#include "Compte.hh"

//Constructeur
Compte::Compte()
{
    Element();
    this->taux = 1 ;
    this->client = " vide " ;//ctor
}

//Obtenir le solde
int Compte::GetSolde(){
    return this->solde;
}

//Obtenir le taux
float Compte::GetTaux(){
    return this->taux;
}
//Obtenir le client
std::string Compte::GetClient(){
    return this->client;
}

//Mis à jour du solde
void Compte::SetSolde(int ajout){
    if(this->solde + ajout <0)
        cout<<"Désolé il n'est pas possible de débité une somme supérieure à celle actuellement sur votre compte.";
    else
    this->solde += ajout ;
}

//Mis à jour du taux
void Compte::SetTaux(float ajout){
    this->taux += ajout ;
}


Compte::~Compte()
{

}
